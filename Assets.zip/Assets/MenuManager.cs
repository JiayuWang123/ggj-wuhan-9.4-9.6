using UnityEngine;
using UnityEngine.SceneManagement; // 如果需要切换场景，必须引入这个命名空间

public class GameController : MonoBehaviour
{
    /// <summary>
    /// 退出游戏的方法
    /// </summary>
    public void QuitGame()
    {
        Debug.Log("正在退出游戏..."); // 在编辑器控制台中打印日志，方便测试

#if UNITY_EDITOR
        // 如果在 Unity 编辑器里运行，点击后停止播放
        UnityEditor.EditorApplication.isPlaying = false;
#else
        // 如果是打包出来的独立游戏（PC/手机等），调用此方法退出
        Application.Quit();
#endif
    }

    /// <summary>
    /// 跳转到指定场景的方法（例如跳转到主菜单或下一个关卡）
    /// </summary>
    /// <param name="sceneName">目标场景的名称</param>
    public void LoadScene(string sceneName)
    {
        SceneManager.LoadScene(sceneName);
    }
}
