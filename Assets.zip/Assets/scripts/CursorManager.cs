using UnityEngine;

public class CursorManager : MonoBehaviour
{
    // 在 Inspector 中拖入你的光标图片
    public Texture2D normalCursor;
    public Texture2D attackCursor;

    // 设置光标的热点（点击中心点）
    private Vector2 hotspot = Vector2.zero;

    void Start()
    {
        // 游戏开始时设置默认光标
        SetNormalCursor();
    }

    // 切换为普通光标
    public void SetNormalCursor()
    {
        // CursorMode.Auto 会根据平台自动选择（推荐）
        Cursor.SetCursor(normalCursor, hotspot, CursorMode.Auto);
    }

    // 切换为攻击光标（比如鼠标悬停在敌人身上时调用）
    public void SetAttackCursor()
    {
        // 如果你的攻击光标是个准星，热点应该在图片中心
        Vector2 centerHotspot = new Vector2(attackCursor.width / 2, attackCursor.height / 2);
        Cursor.SetCursor(attackCursor, centerHotspot, CursorMode.Auto);
    }
}
