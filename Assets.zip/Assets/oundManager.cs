using UnityEngine;
using UnityEngine.Audio; 
using UnityEngine.UI;    

public class SoundManager : MonoBehaviour
{
    [Header("绑定你的 Audio Mixer")]
    public AudioMixer audioMixer;

    private bool isMuted = false;
    private float lastVolume = 1f; 

    /// <param name="sliderValue">Slider 传过来的值，范围建议设置在 0.0001 到 1 之间</param>
    public void SetVolume(float sliderValue)
    {
        // 如果处于静音状态，滑动滑块时自动解除静音
        if (isMuted && sliderValue > 0.0001f)
        {
            isMuted = false;
        }

        // Mixer 的音量是分贝(dB)，范围通常是 -80dB 到 20dB。
        // 使用 Log10(值) * 20 可以将 Slider 的 0~1 线性转化为符合听觉的对数分贝
        float dB = Mathf.Log10(Mathf.Clamp(sliderValue, 0.0001f, 1f)) * 20f;

        audioMixer.SetFloat("MyExposedVolume", dB);

        if (!isMuted)
        {
            lastVolume = sliderValue; 
        }
    }

    /// <summary>
    /// 一键静音 / 取消静音的方法（绑定到 Toggle 或 Button 的 On Click）
    /// </summary>
    public void ToggleMute()
    {
        isMuted = !isMuted;

        if (isMuted)
        {
            // 静音：直接将 Mixer 音量设置为最小分贝 -80dB
            audioMixer.SetFloat("MyExposedVolume", -80f);
        }
        else
        {
            // 取消静音：恢复到静音前的音量大小
            SetVolume(lastVolume);
        }
    }
}
