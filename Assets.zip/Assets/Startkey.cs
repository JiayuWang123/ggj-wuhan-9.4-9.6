using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.EventSystems;

public class PressAnyKeyToStart : MonoBehaviour
{
    [Header("UI 面板配置")]
    [Tooltip("这里可以拖入整个大面板，也可以只拖入那行【请按任意键开始】的小字。建议只拖小字。")]
    public GameObject Startkey;

    [Header("要加载的场景名字（留空则不切换场景）")]
    public string nextSceneName = "";

    private bool isGameStarted = false;

    void Update()
    {
        
        if (isGameStarted) return;

     
        if (Input.anyKeyDown)
        {
           
            if (EventSystem.current != null && EventSystem.current.IsPointerOverGameObject())
            {
                return;
            }

            
            StartGame();
        }
    }

    private void StartGame()
    {
        isGameStarted = true;
        Debug.Log("【游戏】检测到按下任意键，游戏开始！");

        
        if (!string.IsNullOrEmpty(nextSceneName))
        {
            Debug.Log($"【系统】正在切换到场景: {nextSceneName}");
            SceneManager.LoadScene(nextSceneName);
            return; 
        }

      
        if (Startkey != null)
        {
          
            if (Startkey == gameObject)
            {
                Debug.LogError("【严重警告】你把脚本挂在了被隐藏的物体本身上！为了防止游戏卡死，已自动拦截隐藏。请在 Hierarchy 里单独将【请按任意键开始】的那行字拖到变量框里，或者把脚本挂在别的空物体上！");

               
                var renderer = GetComponent<CanvasGroup>();
                if (renderer != null) renderer.alpha = 0;
                else Startkey.SetActive(false);
            }
            else
            {
                
                Startkey.SetActive(false);
            }
        }
    }
}
